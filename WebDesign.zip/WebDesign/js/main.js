// jquery file for main page

$(document).ready(function() {
    // run function on initial page load
    // functionName();

    // run function on resize of the window
    $(window).resize(function() {
      
    });
    // run function on scroll
    $(window).scroll(function() {

    });
});


function functionName() {
  // your function goes here
}